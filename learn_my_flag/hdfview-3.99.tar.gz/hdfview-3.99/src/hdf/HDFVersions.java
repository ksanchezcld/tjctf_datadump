package hdf;

public interface HDFVersions {
    public static final String HDF4_VERSION    = @HDF4_VERSION@;
    public static final String HDF5_VERSION    = @HDF5_VERSION@;
    public static final String HDFVIEW_VERSION = @HDFVIEW_VERSION@;
    public static final String HDFJAVA_VERSION = @HDFJAVA_VERSION@;
}